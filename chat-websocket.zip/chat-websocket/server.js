/**
 * Aplicação de Chat em Tempo Real com Node.js e WebSockets.
 * Atividade: Desenvolvimento Voltado à Web III (UNIGRAN EAD).
 */

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const fs = require('fs');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'mensagens.json');

// Serve os arquivos estáticos da interface (pasta public)
app.use(express.static(path.join(__dirname, 'public')));

// Carrega o histórico salvo no arquivo JSON
function carregarMensagens() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([], null, 2));
    return [];
  }

  try {
    const data = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
}

// Persiste uma nova mensagem no arquivo JSON
function salvarMensagem(novaMensagem) {
  const mensagens = carregarMensagens();
  mensagens.push(novaMensagem);
  fs.writeFileSync(DATA_FILE, JSON.stringify(mensagens, null, 2));
}

// Gerencia conexões WebSocket dos clientes
io.on('connection', (socket) => {
  console.log('Usuário conectado:', socket.id);

  // Envia o histórico existente ao conectar
  socket.emit('historico', carregarMensagens());

  // Recebe mensagem em tempo real, salva e retransmite a todos
  socket.on('chat_message', (data) => {
    const dadosMensagem = {
      usuario: data.usuario,
      texto: data.texto,
      horario: new Date().toLocaleTimeString()
    };

    salvarMensagem(dadosMensagem);
    io.emit('chat_message', dadosMensagem);
  });

  socket.on('disconnect', () => {
    console.log('Usuário desconectado:', socket.id);
  });
});

server.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
