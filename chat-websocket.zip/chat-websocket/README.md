# Sistema de Chat em Tempo Real com Node.js e WebSockets

Aplicação web desenvolvida para a atividade de **Desenvolvimento Voltado à Web III** do curso de Tecnologia em Análise e Desenvolvimento de Sistemas (**UNIGRAN EAD**), utilizando **Node.js**, **Express**, **Socket.io (WebSockets)** e persistência em arquivo **JSON**.

## Funcionalidades e Estrutura do Código

- **`server.js`**: cria o servidor HTTP, serve os arquivos estáticos da pasta `public`, gerencia as conexões WebSocket de múltiplos usuários em tempo real e persiste as mensagens no arquivo `mensagens.json`.
- **`public/index.html`**: interface web onde o usuário informa seu nome, envia mensagens instantaneamente e visualiza o histórico atualizado em tempo real.
- **`mensagens.json`**: arquivo JSON utilizado para armazenar o histórico de mensagens trocadas.
- **`package.json`**: contém os metadados do projeto, o script de execução (`npm start`) e as dependências (`express` e `socket.io`).

## Pré-requisitos

- [Node.js](https://nodejs.org/) instalado na máquina.

## Como instalar as dependências

Na pasta raiz do projeto, execute no terminal:

```bash
npm install
```

## Como executar o servidor

Após instalar as dependências, execute:

```bash
npm start
```

O servidor será iniciado na porta `3000`.

## Como acessar a aplicação no navegador

Abra o navegador e acesse:

```text
http://localhost:3000
```

Digite seu nome, envie mensagens e confirme que elas aparecem em tempo real e ficam salvas em `mensagens.json`.
